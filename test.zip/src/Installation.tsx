import React, { useState, useEffect } from "react";
import Poem from "./Poem";

interface IProps {
  Ititle: string;
  Ipicture: string;
  Isound: string;
}
function Installation({ Ititle, Ipicture, Isound }: IProps) {
  const [poemTitle, setTitle] = useState({ title: Ititle });
  const [picture, setPicture] = useState({ picture: Ipicture });
  const [poemSound, setSound] = useState({ sound: Isound });

  return (
    <div className="installation-wrapper">
      <a href={poemTitle.title}>Poem</a>
      <img src={picture.picture} />
      <Poem title={poemTitle.title}></Poem>
      <audio
        id="my_audio"
        src={poemSound.sound}
        autoPlay={true}
        loop={true}
      ></audio>
    </div>
  );
}

export default Installation;
